## ReactJS: How to create a Data Filter App

### Click on below image to watch the video explanation of this code.

[![React Filter App](./banner.png)](https://youtu.be/4IULKeE0HFI)
